<?php

$server="localhost";
$username="root";
$password="";
$conn=mysqli_connect($server,$username,$password);
if(mysqli_connect_errno()){
    echo "error";
}else{
    echo "successfully connected";
}










?>