<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
       <!-- Required meta tags -->
       <meta charset="utf-8">
       <meta name="viewport" content="width=devicew-width, initial-scale=1">
   
       <!-- Bootstrap CSS -->
       <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
       <link rel="stylesheet" href="style2.css">
   
       <title>Hello, world!</title>
</head>
<body>

       
          <div class="row">.</div>
        <div class="row bck">
            <div class="col-2">

            </div>
            <div class="col-8 ">
                <span class="text1">Welcome To FlyBy!</span>
        
            </div>
           
        </div>
        <div class="row">
            <span class="text2">Where you trust</span>
        </div>
    

        <form  action="http://127.0.0.1:5500/ticket.html" onsubmit="return validateForm()">
                <div class="login-page">
                    <div class="form">
                      <div class="login">
                        <div class="login-header">
                          <h3>LOGIN</h3>
                          <p>Please enter your credentials to login.</p>
                        </div>
                      </div>
                      <form class="login-form">
                        <input type="text" placeholder="username"id="names">
                        <span id="fname" class="text-danger"></span>
                        <input type="password" placeholder="password"id="passwords">
                        <span id="paaswordd" class="text-danger"></span>
                        <button onclick="window.location.href='http://localhost/wbc/ticketnew.php'">login</button>
                       
                      </form>
                    </div>
                  </div>
  </form>
       
      
        
    















    <script>
        function validateForm() {



var name= document.getElementById('names').value;
var pass= document.getElementById('passwords').value;







if (name.length==0) {
    document.getElementById('fname').innerHTML="Please fill this field!";

return false;
}
if (pass.length==0) {
    document.getElementById('paaswordd').innerHTML="Please fill this field!";

return false;
}
if (pass.length < 3) {
    document.getElementById('paaswordd').innerHTML="password length is to short";

return false;
}
        }
    </script>
</body>
</html>