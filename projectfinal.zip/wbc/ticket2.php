<?php

$server="localhost";
$username="root";
$password="";
$con=mysqli_connect($server,$username,$password);
if(mysqli_connect_errno()){
    echo "error";
}else{
    echo "successfully connected";
}

$from=$_POST['from'];
$to=$_POST['to'];
$dept=$_POST['dept'];
$ret=$_POST['ret'];
$adult=$_POST['adult'];
$child=$_POST['child'];
$class=$_POST['class'];
$sql="INSERT INTO 'ticket',`info` (`to`, `from`, `departure`, `return`, `adult`, `children`, `class`)
 VALUES ('$from', '$to', '$dept', '$ret', '$adult', '$child', '$class');";


echo $sql;


if($con->query($sql)==true)
{
    echo"success";
}

else{
    echo"error :$sql<br>$conn->error";
}
$con->close();
?>