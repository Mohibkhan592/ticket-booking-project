<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
</head>
<body>


<table border="2">
    <tr>
        <th>Id</th>
        <th>Name</th>
        <th>Email</th>
        <th>password</th>
        <th>profile_pic</th>
        <th>update</th>
        

    </tr>
<?php
include("databse.php");
$sql="select * from flight";
$result = $conn->query($sql);


//print_r($result);

if($result->num_rows>0){
    foreach($result as $row){
?>
<tr>
<td><?php echo $row['id']; ?></td>
<td><?php echo $row['from']; ?></td>
<td><?php echo $row['to']; ?></td>
<td><?php echo $row['dept']; ?></td>
<td><?php echo $row['ret']; ?></td>
<td><?php echo $row['adult']; ?></td>
<td><?php echo $row['child']; ?></td>
<td><?php echo $row['class']; ?></td>
<td><a href="edit.php?id=<?php echo $row['id']; ?>">Edit</a></td>
    </tr>
    <?php
}  
}


?>


</table>
</body>
</html>