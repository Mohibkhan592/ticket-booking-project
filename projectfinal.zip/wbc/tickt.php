<?php

$servername="localhost";
username="root";
password="";
$conn=mysqli_connect($servername,$username,$password);
if(mysqli_connect_errno()){
    echo "error";
}else{
    echo "successfully connected";
}
















?>