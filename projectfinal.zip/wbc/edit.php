<?php include 'databse.php'; ?>
<html>
    <head>
        
    </head>
    <body>
        <?php 
        $id=$_GET['id'];  
        $sql="select * from adduser where id=$id";
        $result=$conn->query($sql);
       if($result->num_rows>0)
       {
           while($row=$result->fetch_assoc())
           {
        ?>
        <form action="update.php?id=<?php echo $_GET['id']; ?>" method="POST" >
            Name:<input type="text" value="<?php echo $row['name']; ?>" name="first_name" value="" /><br>
            Email:<input type="email" value="<?php echo $row['email']; ?>" name="email" value="" /><br>
            Password: <input type="password" name="password" value="" /><br>
            Profile Pic:<input type="file" name="profile_pic" value="" /><br>
            <input type="submit" name="submit" value="Submit" />
        </form>
       <?php  
       } 
        }
        ?>
    </body>
        
</html>