<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
       <!-- Required meta tags -->
       <meta charset="utf-8">
       <meta name="viewport" content="width=devicew-width, initial-scale=1">
   
       <!-- Bootstrap CSS -->
       <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
       <link rel="stylesheet" href="style3.css">
   
       <title>Hello, world!</title>
</head>
<body>
    
    <br>
    <div class="booking-form-box">
     
<div class="radio-btn">
<input type="radio" class="btn "name="check" checked="checked">
<span class="txt">Roundtrip</span>
<input type="radio" class="btn"name="check">
<span>Oneway</span>
<input type="radio" class="btn"name="check">
<span>Multicity</span>
     
     
</div>
<form action="databse.php" method="post">
    <div class="booking-form txt">
<label>Flying From</label>
<input type="text"name="from" class="form-control" placeholder="city or airport"id="fromcity">
<span id="from" class="text-danger"></span>
<label>Flying To</label>
<input type="text"name="to" class="form-control" placeholder="city or airport"id="tocity">
<span id="to" class="text-danger"></span>

<label>Departure</label>
<input type="text"name="dept" class="form-control select date"placeholder="MM/DD/YYYY"onfocus="(this.type='date')">

<label>Return</label>
<input type="text"name="ret" class="form-control select date"placeholder="MM/DD/YYYY"onfocus="(this.type='date')">

<label>Adults</label>
<input type="number"name="adult" class="form-control select date"value="1">
<label>Children</label>
<input type="number"name="child" class="form-control select date"value="0">

<div class="custom-select  ">
    <label>Ticket Class</label>
    <select class="custom-select bk"name="class">
        <option value="1">Economy class</option>
        <option value="2">Busniess class</option>
    </select>
</div>


<div class="input-grp">
   <a href="http://localhost/wbc/userlist.php"> <input type="submit" name="submit" value="Submit" /></a>
    
</div>

</form>

</div>








    </div>



    <script>
        function validateForm() {



var first= document.getElementById('fromcity').value;
var second= document.getElementById('tocity').value;







if (first.length==0) {
    document.getElementById('from').innerHTML="Please fill this field!";

return false;
}
if (second.length==0) {
    document.getElementById('to').innerHTML="Please fill this field!";

return false;
}
 }
    </script>












</body>
</html>