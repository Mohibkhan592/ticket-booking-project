<?php
$servername="localhost";
$username="root";
$password="";
$my_db="project";

$conn=mysqli_connect($servername,$username,$password,$my_db);

if(mysqli_connect_errno()){
    echo "error";
}else{
    echo "successfully connected";
}


print_r($_POST);

$data['name']=$_POST['Name'];
$data['regno']=$_POST['regno'];
$data['email']=$_POST['email'];
$data['pass']=$_POST['password'];
$sql="insert into students(name,regno,email,pass) values ('".$data['name']."','".$data['regno']."','".$data['email']."','".$data['pass']."')";

if(mysqli_query($conn,$sql)){
    echo "insert successfully";
}else{
    echo "not insert";
}


$sql = 'SELECT name, regno, email, pass FROM students';
   mysql_select_db('studentregform');
   $retval = mysql_query( $sql, $conn );
   
   if(! $retval ) {
      die('Could not get data: ' . mysql_error());
   }
   
   while($row = mysql_fetch_array($retval, MYSQL_ASSOC)) {
      echo "id :{$row['id']}  <br> ".
         "name : {$row['name']} <br> ".
         "regno : {$row['regno']} <br> ".
         "email : {$row['email']} <br> ".
         "pass : {$row['pass']} <br> ".
         "--------------------------------<br>";
   }
echo $sql;
exit();


?>

