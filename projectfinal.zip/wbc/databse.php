<?php

$server="localhost";
$username="root";
$password="";
$my_db="projectnew";


$con=mysqli_connect($server,$username,$password,$my_db);
if(mysqli_connect_errno())
{
    echo "error";

}
else
{
    echo "SUCCESS";
}
print_r($_POST);

$from=$_POST['from'];
$to=$_POST['to'];
$dept=$_POST['dept'];
$ret=$_POST['ret'];
$adult=$_POST['adult'];
$child=$_POST['child'];
$class=$_POST['class'];




$sql="INSERT INTO `flight` (`id`, `from`, `to`, `dept`, `ret`, `adult`, `child`, `class`) VALUES ('', '$from', '$to', '$dept', '$ret', '$adult', '$child', '$class');";
if(mysqli_query($con,$sql)){
    echo "insert successfully";
}
else{
    echo "not insert";
}




exit();
?>